package com.airell.bus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/*
 * Tag menandai sebagai aplikasi test SpringBoot
 */
@SpringBootTest
class FinalProjectBusApplicationTests {
	/*
	 * Digunakan hanya untuk testing aplikasi
	 */
	@Test
	void contextLoads() {
	}
}
