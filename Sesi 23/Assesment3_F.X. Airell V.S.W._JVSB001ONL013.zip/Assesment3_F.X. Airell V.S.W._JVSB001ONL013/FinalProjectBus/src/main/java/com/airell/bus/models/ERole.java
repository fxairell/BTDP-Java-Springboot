package com.airell.bus.models;

/*
 * Kelas publik enumerasi dari Role
 */
public enum ERole {
	ROLE_USER,
	ROLE_ADMIN
}
