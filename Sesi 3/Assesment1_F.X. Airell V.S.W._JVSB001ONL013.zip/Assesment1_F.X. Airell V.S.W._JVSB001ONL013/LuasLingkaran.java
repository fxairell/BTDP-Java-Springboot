public class LuasLingkaran {
    public static void main (String[] args) {
        // Deklarasi variabel
        Double Luas, P1;
        int r;

        // Deklarasi nilai P1 (pi) tetap
        P1 = 3.14;
        // Deklarasi nilai r awal
        r = 18;

        // Proses menghitung luas
        Luas = P1*r*r;

        // Menampilkan luas
        System.out.println("Luas lingkaran dengan jari-jari " + r + " satuan adalah " + Luas + " satuan luas.");
    }
}
